---
name: whiteboard-reviewer
description: Evaluate dark-mode whiteboard HTML outputs with an independent review pass. Use when a separate agent needs to review a generated whiteboard for text overlap, diagram collisions, clipping, readability, rubric scoring, and concrete iteration guidance before the output is accepted.
---

# Whiteboard Reviewer

Use this skill as the evaluation harness for `dark-mode-whiteboard` outputs. The reviewer judges quality; it does not rewrite the whiteboard unless the user explicitly asks for edits.

## Inputs

Provide:

- Absolute path to the generated whiteboard HTML file
- Optional original markdown content or a path to it
- Optional iteration number and prior review history

## Workflow

1. Read `references/rubric.md` before scoring.
2. Inspect the HTML source first.
   - Read the file and inventory all `.wb-text`, `.artifact-text`, and `.artifact-box` elements.
   - Search for `font-size`, `left`, `top`, `width`, `height`, `background`, `background-color`, and `rc.` drawing calls.
   - **Determine the whiteboard mode** (required before scoring R1, R2, R3): Is the content abstract/mathematical (Conceptual mode) or process/workflow/architecture (Structured mode)? Record the mode and apply the correct thresholds for R1 negative space, R2 density, and R3 drawing-to-text ratio.
   - Record quick facts that matter to the rubric: semantic group count per panel, raw `.wb-text` count, total `rc.*` call count, minimum font size, obvious off-canvas placements, artifact count, artifact backgrounds, and whether enough Rough.js drawing exists to support the metaphor requirement.
   - **DOM stacking check:** Inspect whether any `.artifact-box` div (or any div with an opaque `background` or `background-color` where all three RGB channels are ≤ `#C0`) appears **after** the `.text-layer` div in source order. If found, flag as `[blocking]` under R2 — the artifact box will occlude all text and SVG content beneath it.
   - Treat source inspection as a precision aid, not a geometry proof. Use it to identify likely collisions, safe-area violations, and layout-rule breaks that must then be confirmed visually when possible.
3. Render and screenshot the output.
   - Use the `agent-browser` skill to open `file://<absolute-path>`.
   - Set a 1920x1080 viewport before capture.
   - Save a full-page screenshot to `/tmp/whiteboard-review-v<iteration>.png` or a similarly specific path.
   - If rendering fails, continue with source inspection only, but mark the review `INCOMPLETE` and do not return `PASS`.
4. Evaluate like an autoresearch eval loop.
   - Act as the objective evaluator, not the creator.
   - Score the current output against the rubric as it exists now.
   - Prefer the smallest set of fixes most likely to increase score in the next iteration.
   - Prioritize the next focus dimension by weighted severity: `R5`/`R9` first, then `R3`/`R6`/`R10`, then the remaining dimensions.
5. Produce a structured review report.
   - Include the scorecard, weighted total, verdict, issues, and concrete fixes.
   - Call out blocking defects explicitly when overlaps, clipping, unreadable text, or severe semantic misuse are present.

## Evaluation Rules

- Use both rendered output and source inspection whenever rendering succeeds.
- Favor visible evidence over speculation. If source suggests an issue but the screenshot does not confirm it, describe it as a likely risk rather than a confirmed defect.
- A whiteboard passes only when the weighted total reaches the target in `references/rubric.md` and there are no blocking `R5` or `R9` failures.
- Keep feedback actionable. Point to the exact text, area, or visual cluster that needs to move, shrink, simplify, or redraw.
- Recommend one primary next focus dimension per failing review.

## Report Format

Always use this structure:

```markdown
## Whiteboard Review Report

- File: <absolute html path>
- Screenshot: <screenshot path or "not captured">
- Verdict: PASS | FAIL | INCOMPLETE
- Primary Next Focus: <rubric dimension>

### Scorecard

R1 Negative Space (x1): _/5 = \_\_
R2 Content Density (x1): _/5 = **
R3 Visual Sketches (x2): \_/5 = **
R4 Typography (x1): _/5 = \_\_
R5 Alignment (x3): _/5 = **
R6 Organic Feel (x2): \_/5 = **
R7 Focal Clarity (x1): _/5 = \_\_
R8 Color Semantics (x1): _/5 = **
R9 Readability (x3): \_/5 = **
R10 Content Originality (x2): \_/5 = **
TOTAL: **/85
TARGET: 68/85

### Evidence

- Mode: Conceptual | Structured
- Source checks: <semantic group count, raw text count, rc.\* call count, minimum font size, artifact count, obvious layout-rule findings>
- Visual checks: <what the screenshot confirms>

### Issues Found

1. [R?][blocking|major|minor] <issue> - <where it appears>
2. ...

### Recommended Fixes

1. <specific change most likely to improve the score>
2. <next most important change>
3. <optional cleanup>

### Iteration Decision

- <accept or iterate>
- <one-sentence rationale>
```

## Reviewer Notes

- Do not rewrite the rubric unless the user explicitly asks to update the reviewer skill itself.
- If the same defect category appears across iterations and the rubric does not capture it cleanly, note it as a `Rubric Gap Candidate` in `Issues Found` instead of mutating the skill during review.
- Keep the report concise but specific enough that the creating agent can act without guesswork.
