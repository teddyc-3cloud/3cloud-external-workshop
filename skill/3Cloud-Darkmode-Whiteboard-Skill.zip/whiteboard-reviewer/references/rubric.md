# Whiteboard Rubric

Use this rubric as the scoring authority for `whiteboard-reviewer`. Score each dimension from 1-5, multiply by its weight, and compute the weighted total. The target is `68/85`.

## Scoring Scale

| Score | Meaning |
|---|---|
| 1 | Failing - rule is violated or the element is missing |
| 2 | Poor - partially present but major issues remain |
| 3 | Acceptable - meets the minimum bar with visible weaknesses |
| 4 | Good - solid execution with minor issues |
| 5 | Excellent - clean, intentional, and publication-ready |

## Weighted Dimensions

### Critical (x3)

**R5 Alignment & Overflow**
No text overlaps other text. No text bleeds outside container boxes. No element clips at the canvas edge. Text inside artifact boxes has at least 20px padding. Text labels inside Rough.js boxes use the centered `left` + `width` + `text-align:center` placement technique instead of hand-estimated offsets.

**R9 Readability at Distance**
Every text element is readable from a presentation distance. The title is at least 48px. Key labels are at least 28px. Primary labels (standalone Tier 3) are at least 22px. **Exception:** Tier 4 sub-labels (18-20px) are permitted when they directly accompany a Tier 3 element immediately above or beside them and serve only as a descriptor (role attribution, short qualifier). Do not flag 18-20px text as a failure if it is clearly a paired sub-label, not a standalone primary label. Contrast must remain strong on the black background.

### High (x2)

**R3 Visual Sketches**
At least one genuine Rough.js illustration exists. The metaphor is recognizable without relying on labels alone. The metaphor section uses at least 8 drawing calls and reads like a sketch, not a text layout. Additionally, total `rc.*` drawing calls on the main SVG layer must meet the mode target: ≥3× the `.wb-text` count in conceptual mode, ≥1× in structured mode. If the metaphor passes but the overall drawing-to-text ratio is below threshold, cap the score at 3.

**R6 Organic Feel**
The layout feels hand-placed, not grid-snapped. Connectors use curves where appropriate. Clusters are asymmetrical, sizes vary intentionally, and the overall composition feels sketched rather than mechanically aligned.

**R10 Content Originality**
Structured source content is reinterpreted visually rather than copied verbatim as long HTML text. Titles and short key phrases may remain literal, but tables, lists, and code-heavy structures should become schematic drawings.

### Standard (x1)

**R1 Negative Space**
Detect the whiteboard mode first: **Conceptual mode** (abstract/math/algorithmic topics) targets 45-55% black; **Structured mode** (pipelines, workflows, architectures, artifact inventories) targets 30-40% black. Score against the correct threshold — a structured-mode whiteboard with 35% black is not a failure. If mode is ambiguous, prefer the threshold whose target range the output falls within.

**R2 Content Density**
Each panel has at most 10 semantic groups. A semantic group = one primary label (Tier 2 or 3) + optional descriptor (Tier 4) + optional sub-note (Tier 4). Raw `.wb-text` count may legitimately reach 25-30 in structured mode when every element belongs to a named group. Count groups, not raw elements. Penalize only when groups exceed 10 or when text elements exist outside any group.

**R4 Typography Hierarchy**
The hierarchy is obvious: title first, section labels second, annotations third. Sizes, weights, and colors reinforce this order.

**R7 Focal Clarity**
One dominant visual element leads the eye. Supporting elements orbit it rather than competing with it.

**R8 Color Semantics**
Yellow is reserved for headers and key labels, pink for problems, green for solutions, cyan for entities/secondary annotations, red is rare, and white/gray remains the default.

## Score Calculation

```text
Weighted Total = (R1x1) + (R2x1) + (R3x2) + (R4x1) + (R5x3) + (R6x2) + (R7x1) + (R8x1) + (R9x3) + (R10x2)
Maximum = 85
Target = 68
```

## Pass/Fail Rule

- `PASS`: weighted total >= 68 and no blocking `R5` or `R9` failure
- `FAIL`: weighted total < 68, or blocking layout/readability issues remain
- `INCOMPLETE`: rendered review could not be performed, so no pass verdict is allowed

## Review Priorities

When recommending the next fix, prioritize in this order:
1. `R5` and `R9`
2. `R3`, `R6`, and `R10`
3. `R1`, `R2`, `R4`, `R7`, and `R8`

Prefer the smallest high-leverage fix set for the next iteration.

## Out-of-Rubric Checks

These rules from `dark-mode-whiteboard` are not scored but must be flagged as blocking defects in `Issues Found` if violated:

- **White/light backgrounds:** Any `background`, `fill`, or `background-color` where all three RGB channels exceed `#C0` (192) is forbidden. Flag as `[blocking]` under R8.
- **Multiple artifact boxes:** More than one `.artifact-box` element is forbidden. Flag as `[blocking]` under R2.
- **DOM stacking occlusion:** Any `.artifact-box` div (or any div with an opaque `background`/`background-color` where all RGB channels are ≤ `#C0`) that appears **after** the `.text-layer` div in DOM source order will occlude all text and SVG content. Flag as `[blocking]` under R2.
- **Artifact box text cap:** More than 6 `.artifact-text` elements inside a single artifact box is forbidden. Flag as `[major]` under R2.
- **Artifact box border:** The artifact boundary must be a Rough.js dashed rectangle, not a CSS border. Flag as `[minor]` under R6 if CSS border is used instead.
- **Safe area:** No element may be within 50px of any canvas edge (x<50, x>1870, y<50, y>1030). Flag edge violations as `[major]` under R5.
