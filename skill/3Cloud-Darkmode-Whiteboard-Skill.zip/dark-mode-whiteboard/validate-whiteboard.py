#!/usr/bin/env python3
"""
validate-whiteboard.py — Pre-flight validator for dark-mode-whiteboard skill.

Usage:
    python3 validate-whiteboard.py <path-to-whiteboard.html>

Exit codes:
    0 = PASS
    1 = FAIL (violations found)
    2 = Error (file not found, parse error, etc.)
"""

import sys
import re
import json
from pathlib import Path


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def parse_hex(hex_str):
    """Return (r, g, b) tuple from a #RRGGBB or #RGB hex string, or None."""
    hex_str = hex_str.strip().lstrip("#")
    if len(hex_str) == 3:
        hex_str = "".join(c * 2 for c in hex_str)
    if len(hex_str) != 6:
        return None
    try:
        return int(hex_str[0:2], 16), int(hex_str[2:4], 16), int(hex_str[4:6], 16)
    except ValueError:
        return None


def is_light(hex_str):
    """Return True if all RGB channels > 192 (#C0)."""
    rgb = parse_hex(hex_str)
    if rgb is None:
        return False
    return all(c > 192 for c in rgb)


def count_words(text):
    return len(text.strip().split())


# ---------------------------------------------------------------------------
# Checks
# ---------------------------------------------------------------------------


def check_light_backgrounds(content):
    """Anti-pattern #12: No light backgrounds on any element."""
    violations = []

    # Match CSS background / background-color properties (inline styles + style blocks)
    bg_pattern = re.compile(
        r"(?:background(?:-color)?)\s*:\s*(#[0-9a-fA-F]{3,6}|white|#fff|#ffffff)",
        re.IGNORECASE,
    )
    for m in bg_pattern.finditer(content):
        val = m.group(1)
        if val.lower() in ("white", "#fff", "#ffffff") or is_light(val):
            line_no = content[: m.start()].count("\n") + 1
            violations.append(
                {
                    "rule": "AP12_LIGHT_BG",
                    "line": line_no,
                    "value": val,
                    "message": f'Light background "{val}" violates anti-pattern #12. Use #000 instead.',
                }
            )

    # Match fill colors in Rough.js calls: fill: '#XXXXXX'
    fill_pattern = re.compile(
        r'fill\s*:\s*[\'"]?(#[0-9a-fA-F]{3,6})[\'"]?', re.IGNORECASE
    )
    for m in fill_pattern.finditer(content):
        val = m.group(1)
        if is_light(val):
            line_no = content[: m.start()].count("\n") + 1
            violations.append(
                {
                    "rule": "AP12_LIGHT_FILL",
                    "line": line_no,
                    "value": val,
                    "message": f'Light fill color "{val}" violates anti-pattern #12.',
                }
            )

    return violations


def check_dark_text_in_artifacts(content):
    """Anti-pattern #13: No dark text inside artifact boxes."""
    violations = []

    # Find all artifact-text elements and check their color
    artifact_text_pattern = re.compile(
        r'artifact-text[^>]*style="([^"]*)"', re.IGNORECASE | re.DOTALL
    )
    color_pattern = re.compile(r"color\s*:\s*(#[0-9a-fA-F]{3,6})", re.IGNORECASE)

    for m in artifact_text_pattern.finditer(content):
        style = m.group(1)
        for cm in color_pattern.finditer(style):
            val = cm.group(1)
            rgb = parse_hex(val)
            if rgb and all(c < 64 for c in rgb):  # very dark colors
                line_no = content[: m.start()].count("\n") + 1
                violations.append(
                    {
                        "rule": "AP13_DARK_TEXT_IN_ARTIFACT",
                        "line": line_no,
                        "value": val,
                        "message": f'Dark text color "{val}" inside artifact-text violates anti-pattern #13.',
                    }
                )

    return violations


def check_long_text(content):
    """Anti-pattern #11 / max text length: wb-text elements must be ≤10 words."""
    violations = []

    # Match wb-text div content
    wb_pattern = re.compile(r'class="wb-text"[^>]*>\s*([^<]+?)\s*<', re.DOTALL)
    for m in wb_pattern.finditer(content):
        text = m.group(1).strip()
        # Strip HTML entities for word count
        text_clean = re.sub(r"&\w+;", "X", text)
        wc = count_words(text_clean)
        if wc > 10:
            line_no = content[: m.start()].count("\n") + 1
            violations.append(
                {
                    "rule": "AP11_LONG_TEXT",
                    "line": line_no,
                    "value": text[:60],
                    "message": f'wb-text has {wc} words (max 10): "{text[:60]}"',
                }
            )

    return violations


def check_drawing_ratio(content):
    """Drawing-to-text ratio must be ≥1:1 (structured) / ≥3:1 (conceptual).
    We use ≥1:1 as the minimum floor — reviewers enforce the stricter ratio."""
    violations = []

    rc_calls = len(
        re.findall(
            r"\brc\.(line|curve|rectangle|circle|ellipse|polygon|arc|path)\(", content
        )
    )
    wb_count = len(re.findall(r'class="wb-text"', content))

    if wb_count > 0 and rc_calls < wb_count:
        violations.append(
            {
                "rule": "AP03_LOW_DRAWING_RATIO",
                "line": 0,
                "value": f"{rc_calls}:{wb_count}",
                "message": f"Drawing-to-text ratio is {rc_calls}:{wb_count} (drawn:text). Must be ≥1:1. Add more Rough.js drawings or remove text elements.",
            }
        )

    return violations


def check_curve_usage(content):
    """Anti-pattern #8: rc.curve() should be used for connectors, not just rc.line()."""
    violations = []

    line_calls = len(re.findall(r"\brc\.line\(", content))
    curve_calls = len(re.findall(r"\brc\.curve\(", content))

    if line_calls > 0 and curve_calls == 0:
        violations.append(
            {
                "rule": "AP08_NO_CURVES",
                "line": 0,
                "value": f"rc.line={line_calls}, rc.curve=0",
                "message": f"Zero rc.curve() calls found. Connectors between concept elements must use rc.curve() not rc.line(). Anti-pattern #8.",
            }
        )
    elif line_calls > 0 and curve_calls > 0:
        ratio = line_calls / (curve_calls + line_calls)
        if ratio > 0.85 and line_calls > 10:
            violations.append(
                {
                    "rule": "AP08_FEW_CURVES",
                    "line": 0,
                    "value": f"rc.line={line_calls}, rc.curve={curve_calls}",
                    "message": f"{line_calls} rc.line() vs only {curve_calls} rc.curve(). Over-reliance on straight lines. Use rc.curve() for connectors between elements.",
                }
            )

    return violations


def check_safe_area(content):
    """Anti-pattern #9: No content beyond x=1870 or y=1030."""
    violations = []

    # Check for hardcoded x positions > 1870
    x_pattern = re.compile(r"left\s*:\s*(\d+)px")
    for m in x_pattern.finditer(content):
        x = int(m.group(1))
        if x > 1870:
            line_no = content[: m.start()].count("\n") + 1
            violations.append(
                {
                    "rule": "AP09_SAFE_AREA_X",
                    "line": line_no,
                    "value": f"left:{x}px",
                    "message": f"Element at x={x} exceeds safe area boundary of 1870px.",
                }
            )

    # Check for hardcoded y positions > 1030
    y_pattern = re.compile(r"top\s*:\s*(\d+)px")
    for m in y_pattern.finditer(content):
        y = int(m.group(1))
        if y > 1030:
            line_no = content[: m.start()].count("\n") + 1
            violations.append(
                {
                    "rule": "AP09_SAFE_AREA_Y",
                    "line": line_no,
                    "value": f"top:{y}px",
                    "message": f"Element at y={y} exceeds safe area boundary of 1030px.",
                }
            )

    return violations


def check_named_helpers(content):
    """Step 7: Repeated drawing patterns should use named helper functions."""
    violations = []

    # Heuristic: if drawDocIcon or drawArrow or drawStickFigure patterns appear
    # more than 2x but no function definition exists — flag it.
    # (Light check — reviewers do the deeper audit)
    doc_icon_calls = len(re.findall(r"drawDocIcon\s*\(", content))
    doc_icon_def = len(re.findall(r"function\s+drawDocIcon", content))
    if doc_icon_calls > 0 and doc_icon_def == 0:
        violations.append(
            {
                "rule": "HELPER_MISSING",
                "line": 0,
                "value": "drawDocIcon",
                "message": "drawDocIcon is called but not defined as a helper function. Extract into a named function (Section 5.H).",
            }
        )

    return violations


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def validate(html_path):
    path = Path(html_path)
    if not path.exists():
        print(f"ERROR: File not found: {html_path}", file=sys.stderr)
        sys.exit(2)

    content = path.read_text(encoding="utf-8")

    all_violations = []
    all_violations += check_light_backgrounds(content)
    all_violations += check_dark_text_in_artifacts(content)
    all_violations += check_long_text(content)
    all_violations += check_drawing_ratio(content)
    all_violations += check_curve_usage(content)
    all_violations += check_safe_area(content)
    all_violations += check_named_helpers(content)

    # Group by rule
    by_rule = {}
    for v in all_violations:
        by_rule.setdefault(v["rule"], []).append(v)

    # Print report
    print(f"\n{'=' * 60}")
    print(f"WHITEBOARD VALIDATOR: {path.name}")
    print(f"{'=' * 60}")

    if not all_violations:
        print("RESULT: PASS — No violations found.")
        print(f"{'=' * 60}\n")
        sys.exit(0)
    else:
        print(f"RESULT: FAIL — {len(all_violations)} violation(s) found.\n")
        for rule, items in by_rule.items():
            print(f"  [{rule}] — {len(items)} occurrence(s)")
            for v in items:
                loc = f"line {v['line']}" if v["line"] else "global"
                print(f"    • {loc}: {v['message']}")
        print(f"\n{'=' * 60}")
        print(
            "Fix all violations and re-run this script before proceeding to the reviewer."
        )
        print(f"{'=' * 60}\n")

        # Also output machine-readable JSON for orchestrator consumption
        json_out = path.with_suffix(".violations.json")
        json_out.write_text(
            json.dumps(
                {
                    "file": str(path),
                    "pass": False,
                    "violation_count": len(all_violations),
                    "violations": all_violations,
                },
                indent=2,
            )
        )
        print(f"Violations written to: {json_out}")
        sys.exit(1)


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print(
            "Usage: python3 validate-whiteboard.py <path-to-whiteboard.html>",
            file=sys.stderr,
        )
        sys.exit(2)
    validate(sys.argv[1])
