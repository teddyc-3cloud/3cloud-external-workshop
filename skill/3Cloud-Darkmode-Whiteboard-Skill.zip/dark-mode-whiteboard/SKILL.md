---
name: dark-mode-whiteboard
description: Transform dense technical Markdown (CS, AI, math) into a hand-drawn style dark-mode whiteboard slide. Generates a self-contained HTML file using Rough.js for sketchy drawing and Caveat font for handwritten text, with client-side PNG export. Trigger with /whiteboard command followed by markdown content or a file path.
license: MIT
---

# Dark Mode Whiteboard Deconstruction

**Role:** Visual Educator & Technical Summarizer.
**Objective:** Transform dense, technical Markdown content (especially related to computer science, AI, or math) into a highly intuitive, hand-drawn style digital whiteboard.
**Core Philosophy:** Deconstruct complexity using embedded academic "artifacts," functional analogies, and a strict color-coded hand-drawn annotation system.

**Organic-First:** Every element must feel hand-placed, not grid-generated. Apply roughness variance (1.2–2.5), 2-6px natural position offsets, varied stroke widths across similar elements, curve-based connectors (`rc.curve()` preferred over `rc.line()`), organic element clustering with 30-60px gap variance, and afterthought-style annotations (slightly offset, smaller font, slight rotation). The output must look like a real whiteboard drawing, not a CSS layout.

**Drawing-First:** Text is a last resort. Any concept expressible as a sketch with a short label MUST be drawn rather than written. Text elements are limited to titles, section headers, and labels of **1-5 words**. If content requires more than 5 words, convert it to a drawn visual element + short label. Never place prose, bullet lists, or tables as raw text on the canvas.

---

## 1. Invocation

This skill is triggered by the `/whiteboard` command:

```
/whiteboard <markdown content or file path>
```

When invoked:
1. If a file path is provided, read the file contents first.
2. If inline markdown is provided, use it directly.
3. Follow the Execution Workflow (Section 7) to produce the output.

---

## 2. Output Format

Generate a **single self-contained HTML file** that:

- Renders a 1920x1080 black canvas with all whiteboard elements
- Loads dependencies from CDN (Rough.js, Caveat font, html2canvas)
- **Additional CDN libraries are permitted** when they solve a specific visual quality problem (e.g., particle systems, animated transitions, better text measurement). Each added library MUST include an HTML comment above the `<script>` tag explaining the justification (e.g., `<!-- Added: gsap for smooth curve animations -->`). The Export PNG button MUST still function correctly after any library addition.
- Includes a floating "Export PNG" button for client-side screenshot export
- Is fully viewable by opening the HTML file in any modern browser

### HTML Template Structure

Every generated HTML file MUST follow this skeleton:

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>[TOPIC] - Whiteboard</title>
  <link href="https://fonts.googleapis.com/css2?family=Caveat:wght@400;500;600;700&display=swap" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/roughjs@4.6.6/bundled/rough.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/html2canvas@1.4.1/dist/html2canvas.min.js"></script>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body {
      background: #000; /* CRITICAL: MUST stay #000 — anti-pattern #12 */
      color: #E0E0E0;
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
      font-family: 'Caveat', cursive;
    }
    #canvas-container {
      position: relative;
      width: 1920px;
      height: 1080px;
      background: #000; /* CRITICAL: MUST stay #000 — anti-pattern #12 */
      overflow: hidden;
    }
    svg.rough-layer {
      position: absolute;
      top: 0; left: 0;
      width: 1920px;
      height: 1080px;
      pointer-events: none;
    }
    .text-layer {
      position: absolute;
      top: 0; left: 0;
      width: 1920px;
      height: 1080px;
      pointer-events: none;
    }
    .wb-text {
      position: absolute;
      font-family: 'Caveat', cursive;
      color: #E0E0E0;
      line-height: 1.2;
      white-space: pre-wrap;
    }
    .artifact-box {
      position: absolute;
      /* DOM ORDER: artifact-box divs MUST appear BEFORE .text-layer in the HTML — this ensures text and SVG content always render on top without needing z-index */
      background: #000; /* CRITICAL: MUST stay #000 — anti-pattern #12. NEVER use #F5F5F5, #FFF, white, or any color with all RGB channels > #C0 */
      border-radius: 2px;
      padding: 16px;
    }
    .artifact-box svg { display: block; }
    .artifact-text {
      position: absolute;
      font-family: 'Caveat', cursive;
      color: #E0E0E0;
      line-height: 1.2;
      white-space: pre-wrap;
    }
    #export-btn {
      position: fixed;
      top: 20px;
      right: 20px;
      z-index: 1000;
      padding: 10px 20px;
      background: #333;
      color: #fff;
      border: 1px solid #555;
      border-radius: 6px;
      font-family: 'Caveat', cursive;
      font-size: 18px;
      cursor: pointer;
    }
    #export-btn:hover { background: #555; }
  </style>
</head>
<body>
  <button id="export-btn" onclick="exportPNG()">Export PNG</button>
  <div id="canvas-container">
    <svg class="rough-layer" id="rough-svg" xmlns="http://www.w3.org/2000/svg"></svg>
    <!-- Artifact boxes go here (MUST appear before text-layer for correct stacking) -->
    <div class="text-layer" id="text-layer">
      <!-- Hand-written text elements go here as absolutely positioned divs -->
    </div>
  </div>

  <script>
    const rc = rough.svg(document.getElementById('rough-svg'));
    const svg = document.getElementById('rough-svg');

    // --- DRAWING CODE GOES HERE ---
    // Use rc.line(), rc.rectangle(), rc.circle(), rc.arc(), rc.path(), rc.curve()
    // All Rough.js elements get appended: svg.appendChild(rc.line(...))
    //
    // Rough.js options for hand-drawn feel:
    //   roughness: 1.5        (wobble amount, 0 = perfect, 3 = very rough)
    //   bowing: 1              (bow of lines)
    //   stroke: '#COLOR'       (line color)
    //   strokeWidth: 2         (line thickness)
    //   fill: '#COLOR'         (fill color for shapes)
    //   fillStyle: 'hachure'   (hachure, solid, zigzag, cross-hatch, dots, dashed)

    function exportPNG() {
      const btn = document.getElementById('export-btn');
      btn.style.display = 'none';
      html2canvas(document.getElementById('canvas-container'), {
        backgroundColor: '#000000',
        scale: 2,
        useCORS: true,
        width: 1920,
        height: 1080
      }).then(canvas => {
        const link = document.createElement('a');
        link.download = 'whiteboard.png';
        link.href = canvas.toDataURL('image/png');
        link.click();
        btn.style.display = 'block';
      });
    }

    // Anti-pattern guard — runs after all drawing code is executed
    // Detects light backgrounds that violate anti-pattern #12
    (function checkDarkMode() {
      const allEls = document.querySelectorAll('*');
      const warnings = [];
      allEls.forEach(el => {
        const bg = getComputedStyle(el).backgroundColor;
        const m = bg.match(/rgb\((\d+),\s*(\d+),\s*(\d+)\)/);
        if (m) {
          const [r, g, b] = [+m[1], +m[2], +m[3]];
          if (r > 192 && g > 192 && b > 192) {
            warnings.push({ el: el.className || el.tagName, bg });
          }
        }
      });
      if (warnings.length) {
        console.warn('[AP#12 VIOLATION] Light backgrounds detected — fix before accepting output:', warnings);
      }
    })();
  </script>
</body>
</html>
```

---

## 3. Global Aesthetic Rules

- **Background:** Solid black (`#000000`). No gridlines.
- **Line style:** Digital stylus feel. Use Rough.js with `roughness: 1.0-2.0` and `bowing: 1` for slightly imperfect, monoline strokes that simulate Apple Pencil on Notability.
- **Typography:** Caveat font at four tiers for hierarchy:
  - **Tier 1 — Main title:** 48-56px, font-weight 700
  - **Tier 2 — Section headers / solution labels:** 28-40px, font-weight 600
  - **Tier 3 — Labels & annotations:** 22-26px, font-weight 500-600
  - **Tier 4 — Sub-labels & descriptors:** 18-20px, font-weight 400. Only used to annotate a Tier 3 element directly above or beside it (e.g., role attribution, short descriptor). NEVER as a standalone primary label.
  - **Smallest allowed text:** 22px for primary labels. 18px ONLY for Tier 4 sub-labels that directly accompany a Tier 3 element.
- **Readability at distance:** Every text element must be legible if the canvas were projected onto a screen viewed from 6 feet away. If you have to squint, the font is too small.
- **Negative space:** Leave generous dark gaps between clusters. No element should be closer than 60px to another cluster. Target depends on mode: **Conceptual mode** (abstract/math topics) → 45-55% black; **Structured mode** (process/workflow/architecture topics) → 30-40% black. In structured mode, density is managed through clear zoning, not content cutting.
- **Content density:** Maximum **10 semantic groups** per 1920x1080 panel. A semantic group = one primary label (Tier 2 or 3) + optional descriptor (Tier 3 or 4) + optional sub-note (Tier 4). The raw count of `.wb-text` elements MAY reach 25-30 provided every element belongs to a named group and no group exceeds 3 text elements. Count groups, not raw elements. If you exceed 10 groups, consolidate or cut before adding more.
- **Canvas:** 1920x1080px (16:9). All content must fit within this frame.
- **Safe area:** No element within 50px of any canvas edge. This prevents clipping on different displays.
- **Anti-collision:** All text elements must have at least 40px clearance from other text elements. Text inside artifact boxes must have at least 20px padding from all box edges. Text must NEVER overlap with Rough.js drawn shapes (rectangles, lines, ellipses) unless intentionally annotating them.
- **Text-in-box centering:** When a text label belongs inside a Rough.js drawn rectangle (e.g., task boxes, workflow step boxes, pipeline nodes), do NOT manually estimate pixel offsets. Instead, set the text div's `left` and `width` to match the box's x and width, add `text-align:center`, and compute `top` from the box's vertical center: `top = boxY + (boxH - fontSize × 1.2) / 2`. This guarantees consistent horizontal and vertical centering regardless of text length.
- **Organic positioning:** Never place elements on a perfect grid. All element x/y coordinates MUST include a 2-6px natural-feeling offset. Related elements form organic clusters with **varying** inter-element gaps (30-60px range) — never uniform padding.
- **Varied stroke character:** Assign roughness by role — primary structural elements (main boxes, artifact borders, key containers): `roughness: 1.2-1.5`; secondary connectors and flow arrows: `roughness: 1.5-1.8`; annotations, afterthought marks, underlines, highlight circles: `roughness: 2.0-2.5`. Never use the same roughness value for all elements.
- **Curve-preferred connectors:** Use `rc.curve()` with a slight midpoint control-point offset for all connecting arrows between concept elements. Straight `rc.line()` is reserved for structural axes, timeline rails, and dividers only. Curves feel human; straight lines feel digital.
- **Max text element length:** No text div may exceed **8-10 words**. Any content requiring more words MUST be split into a sketched visual element plus a short (≤5 word) label.

---

## 4. The Functional Color Palette

Colors are **semantic, not decorative**. Strictly adhere to this mapping:

| Role | Color | Hex | Usage |
|------|-------|-----|-------|
| **Foundation** | White / Light Gray | `#E0E0E0` / `#AAAAAA` | Standard text, neural network nodes/edges, structural lines, timeline axes |
| **Core Focus** | Yellow | `#FFD54F` | Main headers, essential labels ("Analogy", "Layer Norm"), key symbols (`$` for funding) |
| **Friction** | Pink / Magenta | `#FF4081` | Problems, drawbacks, vanishing/exploding gradients, bottlenecks, distorted data |
| **Solution** | Green | `#69F0AE` | Breakthroughs, innovations, successful paths, new architectures ("ResNet") |
| **Entities** | Cyan / Light Blue | `#4FC3F7` | Company names ("DeepSeek"), secondary annotations, clean/processed data flow |
| **Absolute Limits** | Red | `#FF1744` | Use sparingly. Severe restrictions ("Data Constrained", "Compute Constrained") |

### Color Rules

- Never use a color outside its semantic role.
- Yellow text is reserved for headers and key labels only.
- Pink/Magenta must ONLY appear for problems/friction.
- Green must ONLY appear for solutions/breakthroughs.
- Red is the rarest color on any slide. If you use it more than 2-3 times, you are overusing it.
- White/gray is the most common color. It is the default for anything that doesn't fit another category.

---

## 5. Structural Elements

Compose the whiteboard using a combination of these techniques based on the input content:

### A. The "Artifact" Paste & Annotate

Embed a simulated academic paper figure, graph, matrix, or architecture diagram:

- Render as a **dark-background rectangle** (`.artifact-box`) placed on the dark canvas. Draw a **Rough.js dashed rectangle** on the main SVG layer at the artifact box position (offset ~4px outward so the sketchy border is visible around the div) using `{ stroke: '#444', strokeWidth: 1.5, roughness: 1.5, strokeLineDash: [6, 4] }`. Do NOT use CSS border on the `.artifact-box` — the border must be hand-drawn to match the whiteboard aesthetic.
- Inside the box, draw the diagram using Rough.js with **light strokes (#E0E0E0)** on the dark background. Use light text colors inside artifacts: `#E0E0E0` for primary labels, `#AAAAAA` for secondary/muted text. Use `#444`-`#555` for internal divider lines.
- Draw the diagram in a simplified, schematic style. Do NOT attempt photorealism. Focus on the key structural elements (boxes, arrows, layers, matrices).
- After placing the artifact, draw **colorful arrows** (using the semantic palette) from outside the box pointing INTO specific parts of the diagram.
- Circle or underline critical parts inside the artifact with colored strokes.
- Add short annotation labels next to the arrows explaining what to look at.
- The artifact should occupy roughly 25-35% of the canvas.
- **Artifact box text element cap:** An artifact box SHALL contain no more than 6 text elements (`.artifact-text` divs). If the source content would require more than 6 text elements, simplify the content into a schematic with short labels and Rough.js drawn elements.

### B. The Functional Metaphor

Translate the technical mechanism into a simple, relatable real-world sketch:

- **CRITICAL: The metaphor MUST be a genuine Rough.js drawing, not just colored text labels.** If your metaphor is only text with no drawn shapes, you did it wrong. You must draw actual visual elements — circles, lines, curves, rectangles — that form a recognizable illustration.
- **Drawing ratio:** ≥50% of the whiteboard's visual content area MUST be occupied by Rough.js drawn shapes rather than text elements. The count of Rough.js drawing calls on the main SVG layer SHALL be ≥ the count of `.wb-text` elements.
- **Stick-figure level simplicity.** Think napkin sketch. ≥8 Rough.js drawing calls minimum for the metaphor section alone, forming a recognizable visual metaphor.
- Draw using Rough.js with colored strokes from the semantic palette.
- The drawing should be immediately recognizable without reading the labels. A person who doesn't speak the language should still understand the visual metaphor.
- Examples of what to DRAW (not just label):
  - Water pipe with a bypass valve (drawn with rectangles + curves) = Residual Connections
  - Seesaw on a triangle fulcrum (drawn with lines + circle weights) = Architectural trade-offs
  - Actual cat face sketch (drawn with circles + curves + whisker lines) = Feature representation
  - Funnel shape narrowing (drawn with angled lines + dots flowing through) = Dimensionality reduction
  - Magnifying glass (drawn with circle + handle line, small text → large text) = Amplification
  - Lever arm (drawn with triangle + beam + force arrows) = Force multiplier
- Place a yellow "Analogy:" label above the metaphor sketch.
- The metaphor should occupy roughly 20-30% of the canvas.
- See Section 5.E for concrete Rough.js drawing recipes you can adapt.

### C. The Progression / Timeline

If the content describes an evolution of technology:

- Draw a horizontal white line (timeline axis) along the top or bottom of the canvas.
- Mark eras with tick marks and yellow/cyan labels.
- Highlight the current topic's position on the timeline with a green circle or bracket.
- Keep the timeline simple: 4-8 milestones maximum.
- The timeline should occupy a strip of roughly 80-120px height.

### D. Key Formula or Code Block

If the content involves a mathematical formula or short code snippet:

- Render it in a slightly larger font (28-32px) using white/gray text.
- Surround with a subtle dashed Rough.js rectangle (gray stroke, roughness 2).
- Annotate specific variables or terms with colored arrows pointing to plain-English explanations.

### E. Sketch Recipe Library

Concrete Rough.js drawing patterns you can adapt. All coordinates are relative to an anchor point `(ax, ay)` — substitute your actual placement coordinates.

**Recipe 1: Lever / Force Multiplier**
Use for: amplification, trade-offs, input-output ratio

```javascript
// Fulcrum triangle
svg.appendChild(rc.line(ax, ay, ax - 30, ay + 40, { stroke: '#E0E0E0', strokeWidth: 2, roughness: 1.5 }));
svg.appendChild(rc.line(ax, ay, ax + 30, ay + 40, { stroke: '#E0E0E0', strokeWidth: 2, roughness: 1.5 }));
svg.appendChild(rc.line(ax - 30, ay + 40, ax + 30, ay + 40, { stroke: '#E0E0E0', strokeWidth: 2, roughness: 1.5 }));
// Beam (tilted — small input side higher)
svg.appendChild(rc.line(ax - 120, ay - 25, ax + 120, ay + 15, { stroke: '#E0E0E0', strokeWidth: 3, roughness: 1.5 }));
// Small input (left, pink — the problem/effort)
svg.appendChild(rc.circle(ax - 100, ay - 35, 20, { stroke: '#FF4081', strokeWidth: 2, roughness: 1.5, fill: '#FF4081', fillStyle: 'solid' }));
// Big output (right, green — the amplified result)
svg.appendChild(rc.circle(ax + 100, ay + 5, 50, { stroke: '#69F0AE', strokeWidth: 2, roughness: 1.5, fill: '#69F0AE', fillStyle: 'hachure', hachureGap: 6 }));
// Force arrows
svg.appendChild(rc.line(ax - 100, ay - 55, ax - 100, ay - 40, { stroke: '#FF4081', strokeWidth: 2, roughness: 1 }));
svg.appendChild(rc.line(ax + 100, ay + 60, ax + 100, ay + 35, { stroke: '#69F0AE', strokeWidth: 2, roughness: 1 }));
```

**Recipe 2: Funnel**
Use for: filtering, narrowing, dimensionality reduction, focus

```javascript
// Funnel walls (angled lines)
svg.appendChild(rc.line(ax - 80, ay, ax - 20, ay + 120, { stroke: '#E0E0E0', strokeWidth: 2.5, roughness: 1.5 }));
svg.appendChild(rc.line(ax + 80, ay, ax + 20, ay + 120, { stroke: '#E0E0E0', strokeWidth: 2.5, roughness: 1.5 }));
// Funnel spout
svg.appendChild(rc.line(ax - 20, ay + 120, ax - 20, ay + 160, { stroke: '#E0E0E0', strokeWidth: 2.5, roughness: 1.5 }));
svg.appendChild(rc.line(ax + 20, ay + 120, ax + 20, ay + 160, { stroke: '#E0E0E0', strokeWidth: 2.5, roughness: 1.5 }));
// Dots entering (scattered, pink — raw/messy)
for (let i = 0; i < 6; i++) {
  svg.appendChild(rc.circle(ax - 50 + i * 20, ay - 15 + (i % 2) * 10, 8, { stroke: '#FF4081', strokeWidth: 1.5, roughness: 1.5, fill: '#FF4081', fillStyle: 'solid' }));
}
// Single dot exiting (green — refined)
svg.appendChild(rc.circle(ax, ay + 175, 12, { stroke: '#69F0AE', strokeWidth: 2, roughness: 1.5, fill: '#69F0AE', fillStyle: 'solid' }));
```

**Recipe 3: Pipe with Bypass Valve**
Use for: skip connections, shortcuts, residual paths

```javascript
// Main pipe (horizontal rectangles)
svg.appendChild(rc.rectangle(ax, ay, 200, 40, { stroke: '#E0E0E0', strokeWidth: 2, roughness: 1.5 }));
// Bypass curve (arching over the pipe)
svg.appendChild(rc.curve([[ax + 30, ay], [ax + 60, ay - 60], [ax + 140, ay - 60], [ax + 170, ay]], { stroke: '#69F0AE', strokeWidth: 2.5, roughness: 1.5 }));
// Valve handle on bypass
svg.appendChild(rc.circle(ax + 100, ay - 65, 16, { stroke: '#FFD54F', strokeWidth: 2, roughness: 1.5 }));
// Flow arrows inside pipe
svg.appendChild(rc.line(ax + 60, ay + 20, ax + 80, ay + 20, { stroke: '#4FC3F7', strokeWidth: 2, roughness: 1 }));
svg.appendChild(rc.line(ax + 80, ay + 20, ax + 75, ay + 15, { stroke: '#4FC3F7', strokeWidth: 2 }));
svg.appendChild(rc.line(ax + 80, ay + 20, ax + 75, ay + 25, { stroke: '#4FC3F7', strokeWidth: 2 }));
```

**Recipe 4: Magnifying Glass**
Use for: amplification, inspection, focus, detail

```javascript
// Lens (circle)
svg.appendChild(rc.circle(ax, ay, 100, { stroke: '#E0E0E0', strokeWidth: 2.5, roughness: 1.5 }));
// Handle
svg.appendChild(rc.line(ax + 38, ay + 38, ax + 90, ay + 90, { stroke: '#E0E0E0', strokeWidth: 4, roughness: 1.5 }));
// Small text outside (gray, represents input)
// Large text inside lens (colored, represents amplified output)
// (add wb-text divs for these — the glass makes small things bigger)
```

**Recipe 5: Scale / Balance**
Use for: comparison, trade-offs, weighing options

```javascript
// Fulcrum
svg.appendChild(rc.line(ax, ay + 60, ax - 20, ay + 90, { stroke: '#E0E0E0', strokeWidth: 2, roughness: 1.5 }));
svg.appendChild(rc.line(ax, ay + 60, ax + 20, ay + 90, { stroke: '#E0E0E0', strokeWidth: 2, roughness: 1.5 }));
// Beam (level or tilted)
svg.appendChild(rc.line(ax - 100, ay + 60, ax + 100, ay + 60, { stroke: '#E0E0E0', strokeWidth: 3, roughness: 1.5 }));
// Left pan (pink — the problem/cost)
svg.appendChild(rc.curve([[ax - 100, ay + 60], [ax - 80, ay + 90], [ax - 60, ay + 90], [ax - 40, ay + 60]], { stroke: '#FF4081', strokeWidth: 2, roughness: 1.5 }));
// Right pan (green — the benefit/solution)
svg.appendChild(rc.curve([[ax + 40, ay + 60], [ax + 60, ay + 90], [ax + 80, ay + 90], [ax + 100, ay + 60]], { stroke: '#69F0AE', strokeWidth: 2, roughness: 1.5 }));
// Chains
svg.appendChild(rc.line(ax - 100, ay + 55, ax - 100, ay + 60, { stroke: '#AAAAAA', strokeWidth: 1.5, roughness: 1 }));
svg.appendChild(rc.line(ax + 100, ay + 55, ax + 100, ay + 60, { stroke: '#AAAAAA', strokeWidth: 1.5, roughness: 1 }));
```

**Recipe 6: Simple Process Flow (non-boxed)**
Use for: step-by-step processes, pipelines, workflows. Use curved arrows instead of rigid boxes.

```javascript
// Three circles connected by curved arrows
svg.appendChild(rc.circle(ax, ay, 60, { stroke: '#4FC3F7', strokeWidth: 2, roughness: 1.5 }));
svg.appendChild(rc.circle(ax + 200, ay, 60, { stroke: '#4FC3F7', strokeWidth: 2, roughness: 1.5 }));
svg.appendChild(rc.circle(ax + 400, ay, 60, { stroke: '#69F0AE', strokeWidth: 2, roughness: 1.5 }));
// Curved connector arrows
svg.appendChild(rc.curve([[ax + 30, ay - 5], [ax + 70, ay - 30], [ax + 130, ay - 30], [ax + 170, ay - 5]], { stroke: '#E0E0E0', strokeWidth: 2, roughness: 1.5 }));
svg.appendChild(rc.curve([[ax + 230, ay - 5], [ax + 270, ay - 30], [ax + 330, ay - 30], [ax + 370, ay - 5]], { stroke: '#E0E0E0', strokeWidth: 2, roughness: 1.5 }));
// Arrowheads
svg.appendChild(rc.line(ax + 170, ay - 5, ax + 163, ay - 14, { stroke: '#E0E0E0', strokeWidth: 2 }));
svg.appendChild(rc.line(ax + 170, ay - 5, ax + 160, ay + 2, { stroke: '#E0E0E0', strokeWidth: 2 }));
svg.appendChild(rc.line(ax + 370, ay - 5, ax + 363, ay - 14, { stroke: '#E0E0E0', strokeWidth: 2 }));
svg.appendChild(rc.line(ax + 370, ay - 5, ax + 360, ay + 2, { stroke: '#E0E0E0', strokeWidth: 2 }));
```

**Recipe 7: Labeled Group Pattern**
Use for: pipeline step names with role attributions, artifact names with descriptions, any primary label + sub-label pair.

```html
<!-- Primary label (Tier 3) -->
<div class="wb-text" style="left: 120px; top: 287px; width: 130px; text-align: center; font-size: 22px; font-weight: 600; color: #E0E0E0;">SPECIFY</div>
<!-- Descriptor (Tier 4, directly below — ~26px below primary baseline) -->
<div class="wb-text" style="left: 120px; top: 313px; width: 130px; text-align: center; font-size: 18px; font-weight: 400; color: #AAAAAA;">(Human)</div>
```

Rules: Tier 4 descriptor must sit within 22-26px below the Tier 3 label's top. Same width and `text-align` as the primary label. Color always `#AAAAAA` (muted gray). This pair counts as **one semantic group**.

**Recipe 8: Horizontal Item List**
Use for: artifact inventories, output file lists, step rows with icons. N items in a row, each ~210px apart.

```javascript
// Draw N document icons spaced 210px apart (ax = x start of first item)
drawDocIcon(ax + 0,   ay, '#4FC3F7');  // item 1 icon
drawDocIcon(ax + 210, ay, '#E0E0E0');  // item 2 icon
drawDocIcon(ax + 420, ay, '#4FC3F7');  // item 3 icon
drawDocIcon(ax + 630, ay, '#69F0AE'); // item 4 icon
```
```html
<!-- Item labels (Tier 3) + descriptors (Tier 4) for each -->
<div class="wb-text" style="left: [ax+5]px; top: [ay+80]px; font-size: 22px; font-weight: 500; color: #4FC3F7;">filename.md</div>
<div class="wb-text" style="left: [ax+5]px; top: [ay+106]px; font-size: 18px; font-weight: 400; color: #AAAAAA;">The why &amp; what</div>
```

### H. Reusable JS Helper Functions

Extract repeated drawing patterns into named functions at the top of the `<script>` block, before all drawing calls. This keeps the code readable and prevents subtle inconsistencies across repeated elements.

**drawArrow — arrow with computed arrowhead:**
```javascript
function drawArrow(x1, y1, x2, y2, color, sw) {
  sw = sw || 2;
  svg.appendChild(rc.line(x1, y1, x2, y2, { stroke: color, strokeWidth: sw, roughness: 1.2 }));
  var angle = Math.atan2(y2 - y1, x2 - x1);
  var aLen = 10, aAngle = 0.5;
  svg.appendChild(rc.line(x2, y2,
    x2 - aLen * Math.cos(angle - aAngle),
    y2 - aLen * Math.sin(angle - aAngle),
    { stroke: color, strokeWidth: sw, roughness: 1 }));
  svg.appendChild(rc.line(x2, y2,
    x2 - aLen * Math.cos(angle + aAngle),
    y2 - aLen * Math.sin(angle + aAngle),
    { stroke: color, strokeWidth: sw, roughness: 1 }));
}
```

**drawDocIcon — folded-corner document:**
```javascript
function drawDocIcon(x, y, color) {
  svg.appendChild(rc.path(
    'M ' + x + ' ' + y +
    ' L ' + (x + 65) + ' ' + y +
    ' L ' + (x + 65) + ' ' + (y + 20) +
    ' L ' + (x + 90) + ' ' + (y + 20) +
    ' L ' + (x + 90) + ' ' + (y + 75) +
    ' L ' + x + ' ' + (y + 75) + ' Z',
    { stroke: color, strokeWidth: 1.5, roughness: 1.5 }
  ));
  svg.appendChild(rc.line(x + 65, y, x + 90, y + 20, { stroke: color, strokeWidth: 1, roughness: 1.2 }));
  svg.appendChild(rc.line(x + 12, y + 32, x + 72, y + 32, { stroke: '#444', strokeWidth: 1, roughness: 1.5 }));
  svg.appendChild(rc.line(x + 12, y + 44, x + 55, y + 44, { stroke: '#444', strokeWidth: 1, roughness: 1.5 }));
  svg.appendChild(rc.line(x + 12, y + 56, x + 65, y + 56, { stroke: '#444', strokeWidth: 1, roughness: 1.5 }));
}
```

**drawStickFigure — human actor with optional tool:**
```javascript
function drawStickFigure(x, y) {
  svg.appendChild(rc.circle(x, y, 18, { stroke: '#FFD54F', strokeWidth: 1.5, roughness: 1.2 }));
  svg.appendChild(rc.line(x, y + 9,  x, y + 50,     { stroke: '#E0E0E0', strokeWidth: 1.5, roughness: 1.2 }));
  svg.appendChild(rc.line(x - 16, y + 28, x, y + 30, { stroke: '#E0E0E0', strokeWidth: 1.5, roughness: 1.2 }));
  svg.appendChild(rc.line(x, y + 30, x + 22, y + 20, { stroke: '#E0E0E0', strokeWidth: 1.5, roughness: 1.2 }));
  svg.appendChild(rc.line(x, y + 50, x - 14, y + 82, { stroke: '#E0E0E0', strokeWidth: 1.5, roughness: 1.2 }));
  svg.appendChild(rc.line(x, y + 50, x + 14, y + 82, { stroke: '#E0E0E0', strokeWidth: 1.5, roughness: 1.2 }));
}
```

**drawCheckpoint — QA gate / review marker:**
```javascript
function drawCheckpoint(x, y, color) {
  color = color || '#FFD54F';
  // Diamond shape
  svg.appendChild(rc.polygon([[x, y - 20], [x + 16, y], [x, y + 20], [x - 16, y]], {
    stroke: color, strokeWidth: 2, roughness: 1.5
  }));
  // Checkmark inside
  svg.appendChild(rc.line(x - 6, y + 2, x - 1, y + 8,  { stroke: color, strokeWidth: 2, roughness: 1.8 }));
  svg.appendChild(rc.line(x - 1, y + 8, x + 8, y - 6,  { stroke: color, strokeWidth: 2, roughness: 1.8 }));
}
```

### G. Zone-Based Composition

For structured content (pipelines, workflows, architectures, artifact inventories), divide the 1920x1080 canvas into named horizontal bands. This provides structure without sacrificing the hand-drawn aesthetic.

**Zone definitions:**
- **Header Zone** (y: 50–160px, ~15%): Title (Tier 1), subtitle (Tier 2), problem statement (Tier 2/pink)
- **Core Zone** (y: 160–700px, ~50%): Main diagram or artifact box (left half), metaphor sketch (right half)
- **Detail Zone** (y: 700–950px, ~25%): Supporting lists, artifact inventories, icon rows, secondary labeled groups
- **Insight Strip** (y: 950–1030px, ~8%): Single key takeaway sentence (Tier 2/green)

**Zone separators:** Draw subtle dashed Rough.js lines between zones where a visual break helps readability:
```javascript
// Zone divider (e.g., between Detail Zone and Insight Strip at y=938)
svg.appendChild(rc.line(80, 938, 1840, 938, {
  stroke: '#333', strokeWidth: 1, roughness: 1.5, strokeLineDash: [8, 6]
}));
```

**When to use zones:** Choose zone-based composition (Structured mode) when:
- Content describes a named process, workflow, pipeline, or architecture
- Content includes an inventory of named artifacts, outputs, or deliverables
- Raw text element count would naturally exceed 15 without grouping

**When NOT to use zones:** Use organic layout (Conceptual mode) when:
- Content is abstract, mathematical, or algorithmic (gradient descent, attention mechanisms)
- Content has 1-2 core concepts and benefits from generous negative space

**Organic feel within zones:** Zone boundaries are intentional structure. Organic feel applies to elements *within* zones: apply 2-6px position jitter, vary gaps within the 30-60px range, use `rc.curve()` for connectors between elements inside a zone.

### F. Anti-Patterns (What NOT to Do)

These are common mistakes that produce poor-quality whiteboards. Avoid all of them:

1. **No Tier 4 as a primary label.** 18-20px text is only permitted as a descriptor directly below a Tier 3 element. Never use it as the sole label for a section or concept.
2. **No more than 10 semantic groups per panel.** Count groups (primary label + optional descriptor + optional sub-note), not raw text elements. If you exceed 10 groups, consolidate or cut before adding more.
3. **No purely text-based metaphors.** If your metaphor section has zero Rough.js drawing calls, you are writing a bullet list, not drawing a whiteboard. The metaphor MUST include drawn shapes.
4. **No perfect grid alignment.** Elements should feel naturally placed, not snapped to a grid. Stagger positions by ±5-15px for organic feel.
5. **No text overlapping container boundaries.** Text inside artifact boxes must have padding. Text outside must not cross into box edges.
6. **No text placed directly on top of other text.** All text elements need ≥40px clearance.
7. **No more than 1 artifact box per panel.** One bordered box is an accent. Two is clutter.
8. **No straight-line connectors between sections.** Use `rc.curve()` for organic flow. Straight horizontal/vertical lines feel robotic.
9. **No content below y=1030 or right of x=1870.** Safe area prevents clipping.
10. **No boxes used as the primary visual element.** Boxes are containers for artifacts. For everything else, use drawn sketches and flowing annotations.
11. **No content transcription.** Tables, lists, code blocks, and structured data from the source markdown MUST be visually reinterpreted as schematic drawings. NEVER reproduce them as HTML text. If the source has a 4-row table, draw a 4-node schematic. If it has a bullet list, draw a flow. Titles and single-sentence quotes may remain verbatim.
12. CRITICAL: **ZERO white or near-white backgrounds.** This is a dark-mode whiteboard. NEVER use `#FAFAFA`, `#F0F0F0`, `#FFF`, `#FFFFFF`, `white`, or ANY hex value where all three RGB channels are above `#C0` (192) as a `background`, `fill`, or `background-color` on ANY element — including `.artifact-box`. Artifact boxes use `background: #000` (same as canvas). Their boundary is defined by a hand-drawn Rough.js dashed rectangle, not by background contrast. If you catch yourself writing a light background color, STOP and use `#000` instead.
13. **No dark-on-light text inside artifacts.** All text inside `.artifact-box` elements must use light colors (`#E0E0E0`, `#AAAAAA`, or semantic palette colors). NEVER use `#222`, `#333`, `#000`, or any dark color as text `color` inside an artifact. The `.artifact-text` class defaults to `color: #E0E0E0`.

---

## 5.5 Visual Conversion Guide

When transforming source content into whiteboard elements, apply these mandatory conversion rules. Text-heavy input patterns MUST become drawn equivalents — never rendered as raw text blocks.

| Source Pattern | Whiteboard Equivalent |
|---|---|
| **Table** | Drawn Rough.js grid (lines forming cells) with short cell labels (≤3 words each), OR connected node diagram for relational data |
| **Bullet list** | A row or column of sketched icons with 1-3 word labels beneath each icon |
| **Paragraph / prose** | Annotated diagram with 2-4 word annotation labels; prose text is not permitted on the canvas |
| **Before/after or pros/cons comparison** | Two contrasting side-by-side sketches (not text columns) |
| **Sequential process / numbered steps** | Connected boxes or circles with flow arrows; no numbered text steps |

Apply these rules before composing layout (Step 6). If source content fits multiple patterns, choose the most visual representation.

---

## 6. Density & Auto-Split

### Whiteboard Modes

Before composing layout, choose the mode that matches the content type:

**Conceptual Mode** (abstract / mathematical / algorithmic topics):
- Target 45-55% black negative space
- Organic layout — no enforced zone bands
- Drawing-to-text ratio ≥ 3:1
- Examples: gradient descent, attention mechanisms, transformer architecture

**Structured Mode** (process / workflow / architecture / artifact-inventory topics):
- Target 30-40% black negative space
- Zone-based layout (Section 5.G) — Header, Core, Detail, Insight Strip
- Drawing-to-text ratio ≥ 1:1 (labeled groups legitimately increase text count)
- Examples: CI/CD pipelines, OpenSpec workflow, software architecture diagrams
- Use labeled group pattern (Recipe 7) and horizontal item list (Recipe 8) as needed

### Single Slide (Default)

For content that maps to 1-2 core concepts, produce a single 1920x1080 canvas. Each panel should have a **single focal point** — one dominant visual element that the eye goes to first (the artifact, the metaphor sketch, or one key diagram). Everything else is supporting context.

### Auto-Split (2-3 Panels)

If the input markdown contains:
- More than **3** distinct major concepts, OR
- More than 2 significant diagrams needed, OR
- A timeline with 8+ milestones AND other structural elements, OR
- You cannot fit the content while keeping ≥40% negative space (conceptual mode) or ≥30% negative space (structured mode) within 10 semantic groups per panel

Then auto-split into 2-3 separate canvases within the same HTML file.

**When in doubt, split.** A clean 2-panel whiteboard with breathing room is always better than a cramped single panel. It is far easier to have too little content per panel than too much.

Split rules:
- Stack the canvases vertically with 40px black gap between them.
- Adjust the `#canvas-container` height accordingly (e.g., 2200px for 2 panels, 3280px for 3 panels).
- Each panel is still 1920x1080 and must independently satisfy all rules in Section 3 (negative space, text cap, safe area, anti-collision).
- Each panel should have its own **single focal point**. Do not spread one diagram across panels.
- The "Export PNG" button should capture all panels.
- Adjust html2canvas height in the export function to match.
- Add a subtle white dashed divider line between panels.

---

## 7. Execution Workflow

When the `/whiteboard` command is invoked with markdown content:

### Step 1: Extract the Core Conflict
- Identify the main problem being solved in the content.
- Assign Pink/Magenta color role.
- Write a 3-8 word problem statement.

### Step 2: Extract the Core Solution
- Identify the breakthrough or answer.
- Assign Green color role.
- Write a 3-8 word solution statement.

### Step 3: Identify the Artifact
- Determine which chart, matrix, architecture diagram, or figure best represents the technical core.
- Sketch it as a simplified schematic for the artifact box.
- **REMINDER: The artifact MUST be a schematic, not a reproduction.** If the source markdown contains a table, list, or code block, do NOT reproduce it as HTML text. Instead, design a visual schematic using Rough.js shapes with short labels (1-5 words each) that captures the insight. Maximum 6 `.artifact-text` elements inside the artifact box.

### Step 4: Draft the Metaphor
- Create a simple real-world analogy that explains the mechanism to a layperson.
- Sketch it at stick-figure level complexity.

### Step 5: Assess Density
- Count the number of major concepts, required diagrams, and timeline milestones.
- **Select mode:** Is this content abstract/mathematical (Conceptual mode) or process/workflow/architecture (Structured mode)? This determines layout strategy, negative space target, and drawing-to-text ratio (see Section 6).
- Decide: single slide or auto-split (2-3 panels).

### Step 6: Compose Layout
- **Identify the single focal point** for this panel. Everything else supports it.
- **Drawing gate:** For each text element you are about to place, ask: *"Can this be a drawing instead?"* Convert wherever possible using the Visual Conversion Guide (Section 5.5) and Visual Vocabulary (Section 8.5). Target a **≥3:1 drawn-to-text ratio** (count `rc.*` calls vs text div elements).
- Place the focal element (artifact box or metaphor sketch) at the visual center of gravity — not dead center, but slightly off-center for organic feel (e.g., center-left or upper-center-right).
- Place the title (top-left area, yellow, largest font). Stagger by ±5-15px from perfect corner alignment.
- Place supporting elements in **natural clusters** around the focal point:
  - Problem statement (pink) near the top or near friction elements
  - Solution statement (green) near solution elements
  - Annotations flow outward from the focal element, like notes scribbled around a main drawing
- **Organic placement principles:**
  - **Vary element sizes noticeably** (don't make all annotations the same font size — use Tier 3/4 range)
  - Use **curved connectors** (`rc.curve()`) between related elements, never straight horizontal/vertical lines
  - Leave **asymmetric margins** (more space on one side than the other — avoid centered symmetry)
  - Place annotations at slight angles relative to each other, as if written at different times
  - Group related items in loose clusters with generous gaps between clusters (≥80px)
- If timeline exists, place along top or bottom edge.
- If formula exists, place near the artifact with annotations.
- **Verify:** Target negative space based on mode: ≥45% (conceptual) or ≥30% (structured). If not met, cut content until it does.

### Step 7: Generate HTML
- Write the complete self-contained HTML file following the template in Section 2.
- Use Rough.js for all drawn elements (lines, shapes, arrows, circles, underlines).
- Use absolutely positioned `<div>` elements with Caveat font for all text.
- Use `.artifact-box` elements for embedded paper figures.
- **Extract repeated drawing patterns into named helper functions** (`drawArrow`, `drawDocIcon`, `drawStickFigure`, `drawCheckpoint`) at the top of the `<script>` block, before all drawing calls (see Section 5.H).
- Include the Export PNG button, script, and the anti-pattern guard block from the template.

#### Pre-flight Self-Audit (mandatory before Step 8)

After generating the HTML but **before saving**, perform this self-audit. Treat each item as a hard gate — fix any failure before proceeding:

1. **AP#12 — Light backgrounds:** Search every `background`, `background-color`, and `fill` value in the generated HTML. If any hex value has all three RGB channels > `#C0` (192), or uses `white`/`#fff`/`#ffffff`, replace it with `#000`. The `.artifact-box` class **must** use `background: #000`.
2. **AP#13 — Dark text in artifacts:** Search all `.artifact-text` elements for `color` values. Any `color: #222`, `#333`, `#000`, or other dark value must be replaced with `#E0E0E0`.
3. **AP#11 — Long text:** Count words in each `wb-text` div. Any element with >10 words must be converted to a drawn visual + short label.
4. **AP#08 — Curve connectors:** Count `rc.curve()` vs `rc.line()` calls. If `rc.curve()` count is 0, add curves for at least the main concept-to-concept connectors.
5. **Drawing ratio:** Count total `rc.*` drawing calls vs total `.wb-text` elements. If drawn < text, add more Rough.js shapes or remove text elements until drawn ≥ text.
6. **Safe area:** Confirm no `left:` value > 1870px and no `top:` value > 1030px.

### Step 8: Save and Validate HTML
- Save the HTML file to the current working directory as `whiteboard-[topic-slug].html`.
- Run the validation script immediately after saving:
  ```
  python3 <skill-dir>/validate-whiteboard.py whiteboard-[topic-slug].html
  ```
  where `<skill-dir>` is the directory containing this SKILL.md file.
- If the script returns **FAIL**:
  - Read the violations list from the script output (or `.violations.json` sidecar file).
  - Fix each violation directly in the HTML.
  - Re-save and re-run the script.
  - Repeat until the script returns **PASS**.
  - Maximum 3 fix-and-rerun cycles. If still failing after 3 cycles, note the remaining violations and proceed — the reviewer loop will handle them.
- Only after the script returns **PASS** (or 3 cycles exhausted) proceed to Step 9.

### Step 9: Request Independent Review
- Spawn a separate review agent/task for each evaluation pass. The creating agent MUST NOT be the final judge of its own output.
- In that separate agent, load the `whiteboard-reviewer` skill and provide:
  - the absolute path to `whiteboard-[topic-slug].html`
  - the original markdown content or file path
  - the current iteration number
  - prior review history if this is not the first pass
- Example `Task` handoff:

```text
description: "Review whiteboard output"
subagent_type: "general"
prompt: "Load the whiteboard-reviewer skill and review `/absolute/path/to/whiteboard-topic.html`. Original markdown: `/absolute/path/to/topic.md`. Iteration: 2. Prior review summary: R5 overlap near artifact box, R9 annotation too small. Return the report in the exact skill format."
```

- The prompt MUST tell the reviewer to load `whiteboard-reviewer`, include the exact file path, include enough prior-review context to avoid repeating the same generic advice, and request the exact review-report format.
- The reviewer uses `agent-browser` to render the file, capture a screenshot, inspect the HTML source, and return a structured review report.
- The reviewer report is the source of truth for pass/fail, score breakdown, blocking defects, and next-step guidance.

### Step 10: Parse Reviewer Report
- Read the reviewer report carefully.
- Record the score for each rubric dimension (R1-R11), the weighted total, the verdict (`PASS`, `FAIL`, or `INCOMPLETE`), and the reviewer-selected primary next focus.
- Preserve the report from every iteration so you can show score progression and explain what changed between versions.
- Treat blocking `R5` and `R9` findings as highest priority even if another dimension has a lower raw score.

### Step 11: Iterate if Needed (Max 10 Iterations)
- **If the reviewer returns `PASS` and the weighted total is ≥76/95 (80%):** Accept the output. Proceed to Step 12.
- **If the reviewer returns `FAIL` or `INCOMPLETE`:** Revise the HTML and request a fresh review from a new reviewer agent/task.
- **Autoresearch-style improvement loop:** Use the reviewer as the eval harness. Make the smallest targeted changes most likely to improve the next score rather than rewriting the whole board at once.
- **Single-dimension focus:** Each iteration targets the reviewer-selected primary next focus, using weight priority (3x > 2x > 1x). Typical fixes include:
  - R5 (Alignment & Overflow): Move or resize text, improve box padding, clear clipping, remove collisions.
  - R9 (Readability at Distance): Increase font sizes, simplify labels, strengthen contrast, reduce clutter.
  - R3 (Visual Sketches): Add or improve Rough.js drawings so the metaphor reads visually.
  - R6 (Organic Feel): Break rigid alignment, vary spacing, and replace straight connectors with curves where appropriate.
  - R10 (Content Originality): Replace verbatim structured text with schematic drawings.
  - R11 (Structural Clarity): Add zone dividers, group related elements, define clear zones for structured-mode content.
- Re-save the HTML (overwrite), then launch a fresh reviewer task for the next iteration. Do not re-use the previous reviewer context.
- After iterations 3, 6, and 9, compare reviewer reports. If the same failure mode persists and does not fit the rubric cleanly, note it as a rubric-gap candidate in the final report instead of mutating the skill during the generation loop.
- **Accept output** when the reviewer passes it or when the max iteration count is reached. If the max is reached without a pass, report the best score achieved and the remaining blockers.

### Step 12: Report
- Report the file path to the user.
- Include the final reviewer score breakdown (all 11 dimensions + weighted total) and the reviewer verdict.
- If iterations occurred, include a **score progression table** showing the score for each dimension at each iteration, plus the weighted total progression.
- Briefly note what reviewer feedback was addressed in each iteration and whether any blockers remain.
- Suggest opening in a browser to view and export.

---

## 7.5 Batch Mode (Multiple Markdown Files)

### Invocation

```
/whiteboard file1.md file2.md file3.md
/whiteboard ./slides/*.md
```

When more than one input file is detected, switch to batch mode instead of single-file mode.

### Isolation guarantee

Each file is **fully independent**:
- No cross-file references. Each sub-agent receives exactly one markdown file.
- No shared output paths. Each produces its own `whiteboard-[topic-slug].html` derived from its own filename.
- No shared context. Each sub-agent runs in a fresh Task context window.
- The orchestrator never passes one sub-agent's output into another.

### Orchestration flow

```
1. Parse input → list of N markdown file paths

2. Fan-out — spawn N Task agents in parallel (one per file):
   - Each agent: load dark-mode-whiteboard skill → run Steps 1-8
     (generate HTML, pre-flight self-audit, save, run validate-whiteboard.py)
   - Each agent reports back: { file, html_path, validation_pass, violations }

3. Collect results from all N agents.

4. Retry loop — for any agent that returned validation FAIL:
   - Spawn a fresh retry Task agent for that file only (fresh context).
   - Pass to the retry agent:
     • the HTML path
     • the violations list (from .violations.json sidecar)
     • the source markdown path
     • retry attempt number (max 3 per file)
   - Retry agent fixes violations, re-saves, re-runs validate-whiteboard.py.
   - Repeat until PASS or max 3 retries exhausted.

5. Reviewer fan-out — once all files pass validation (or retries exhausted):
   - Spawn N reviewer Task agents in parallel (one per file).
   - Each reviewer: load whiteboard-reviewer skill → review its assigned HTML.
   - Each reviewer reports: { file, score, verdict, blocking_defects }

6. Reviewer retry loop — for any reviewer FAIL:
   - Spawn a fresh fix Task agent for that file.
   - Pass: HTML path, source markdown, reviewer report, iteration count.
   - Max 10 iterations per file (same as single-file mode).
   - After fix, spawn a fresh reviewer agent for re-evaluation.

7. Fan-in — collect all final results and report summary table to user.
```

### Summary table format

```
| File                              | Validation | Reviewer Score | Verdict | Iterations |
|-----------------------------------|------------|----------------|---------|------------|
| whiteboard-01-start-with-why.html | PASS       | 82/95          | PASS    | 2          |
| whiteboard-02-spec-to-blueprint   | PASS (r2)  | 79/95          | PASS    | 3          |
| whiteboard-03-greenfield-build    | PASS       | 88/95          | PASS    | 1          |
```

`PASS (r2)` means validation passed on the 2nd retry attempt.

### Task agent prompt template (for fan-out)

When spawning each sub-agent, use this prompt structure:

```
Load the dark-mode-whiteboard skill and generate a whiteboard for:
  Source markdown: <absolute-path-to-file.md>
  Output path: <absolute-path-to-output-dir>/whiteboard-<slug>.html
  Skill dir (for validate-whiteboard.py): <absolute-path-to-skill-dir>

Follow the full single-file workflow (Steps 1-8 only — do NOT spawn a reviewer).
After saving, run validate-whiteboard.py and fix any violations (max 3 cycles).
Report back: { file, html_path, validation_pass, violation_count, violations }
```

### Retry agent prompt template

```
Fix validation violations in a whiteboard HTML file.
  HTML file: <absolute-path-to-whiteboard.html>
  Source markdown: <absolute-path-to-source.md>
  Violations: <paste violations list from .violations.json>
  Retry attempt: <N> of 3
  Skill dir: <absolute-path-to-skill-dir>

Read the HTML file, fix each listed violation, save, and re-run validate-whiteboard.py.
Report back: { file, html_path, validation_pass, violation_count }
```

---



Quick reference for common drawing operations:

```javascript
// Arrow (line + arrowhead)
svg.appendChild(rc.line(x1, y1, x2, y2, { stroke: '#FFD54F', strokeWidth: 2, roughness: 1.5 }));
// Draw arrowhead as two short lines at the endpoint
svg.appendChild(rc.line(x2, y2, x2 - 10, y2 - 8, { stroke: '#FFD54F', strokeWidth: 2 }));
svg.appendChild(rc.line(x2, y2, x2 - 10, y2 + 8, { stroke: '#FFD54F', strokeWidth: 2 }));

// Circling something important
svg.appendChild(rc.ellipse(cx, cy, width, height, { stroke: '#FF4081', strokeWidth: 2, roughness: 2, fill: 'none' }));

// Box / container
svg.appendChild(rc.rectangle(x, y, w, h, { stroke: '#E0E0E0', strokeWidth: 1.5, roughness: 1.5 }));

// Dashed box (for formulas)
svg.appendChild(rc.rectangle(x, y, w, h, { stroke: '#AAAAAA', strokeWidth: 1, roughness: 2, strokeLineDash: [8, 6] }));

// Neural network node
svg.appendChild(rc.circle(cx, cy, diameter, { stroke: '#E0E0E0', strokeWidth: 1.5, roughness: 1 }));

// Filled shape (solution highlight)
svg.appendChild(rc.rectangle(x, y, w, h, {
  stroke: '#69F0AE', strokeWidth: 2, roughness: 1.5,
  fill: '#69F0AE', fillStyle: 'hachure', fillWeight: 1, hachureGap: 8
}));

// Curvy connector
svg.appendChild(rc.curve([[x1,y1], [cx1,cy1], [cx2,cy2], [x2,y2]], { stroke: '#4FC3F7', strokeWidth: 2, roughness: 1.5 }));
```

---

## 8.5 Visual Vocabulary

Before writing a word as a text label, check this symbol library. These Rough.js snippets are ready-made primitives for common concepts. **Reach for a symbol before reaching for text.**

**Available symbols:** lightbulb (idea/insight), gear (process/system), person (user/actor), checkmark (success/done), X mark (failure/removed), warning triangle (caution/risk), clock (time/duration), funnel (filtering/narrowing), target/bullseye (goal/objective), cloud (abstract/external/vague).

### Lightbulb (idea/insight)
```javascript
// cx, cy = center of bulb
svg.appendChild(rc.circle(cx, cy, 40, { stroke: '#FFD54F', strokeWidth: 2, roughness: 1.5 }));
svg.appendChild(rc.curve([[cx-8, cy+16], [cx-6, cy+28], [cx+6, cy+28], [cx+8, cy+16]], { stroke: '#FFD54F', strokeWidth: 2, roughness: 2.0 }));
svg.appendChild(rc.line(cx, cy+30, cx, cy+38, { stroke: '#FFD54F', strokeWidth: 2, roughness: 1.8 }));
```

### Person (user/actor)
```javascript
// cx, cy = top of head center
svg.appendChild(rc.circle(cx, cy, 24, { stroke: '#E0E0E0', strokeWidth: 2, roughness: 1.5 }));           // head
svg.appendChild(rc.line(cx, cy+12, cx, cy+52, { stroke: '#E0E0E0', strokeWidth: 2, roughness: 1.5 }));    // body
svg.appendChild(rc.line(cx, cy+26, cx-18, cy+40, { stroke: '#E0E0E0', strokeWidth: 2, roughness: 1.8 })); // left arm
svg.appendChild(rc.line(cx, cy+26, cx+18, cy+40, { stroke: '#E0E0E0', strokeWidth: 2, roughness: 1.8 })); // right arm
svg.appendChild(rc.line(cx, cy+52, cx-14, cy+74, { stroke: '#E0E0E0', strokeWidth: 2, roughness: 1.8 })); // left leg
svg.appendChild(rc.line(cx, cy+52, cx+14, cy+74, { stroke: '#E0E0E0', strokeWidth: 2, roughness: 1.8 })); // right leg
```

### Checkmark (success/done)
```javascript
// cx, cy = center of checkmark bounding box
svg.appendChild(rc.line(cx-16, cy+2, cx-4, cy+16, { stroke: '#69F0AE', strokeWidth: 2.5, roughness: 1.8 }));
svg.appendChild(rc.line(cx-4, cy+16, cx+18, cy-14, { stroke: '#69F0AE', strokeWidth: 2.5, roughness: 1.8 }));
```

### Warning Triangle (caution/risk)
```javascript
// cx, cy = center of triangle
svg.appendChild(rc.polygon([[cx, cy-30], [cx-26, cy+18], [cx+26, cy+18]], { stroke: '#FFD54F', strokeWidth: 2, roughness: 1.8, fill: 'none' }));
svg.appendChild(rc.line(cx, cy-12, cx, cy+6,  { stroke: '#FFD54F', strokeWidth: 2.5, roughness: 2.0 })); // exclamation stem
svg.appendChild(rc.circle(cx, cy+12, 4, { stroke: '#FFD54F', strokeWidth: 2, roughness: 2.0 }));          // exclamation dot
```

### Funnel (filtering/narrowing)
```javascript
// cx, cy = center of funnel
svg.appendChild(rc.polygon([[cx-40, cy-20], [cx+40, cy-20], [cx+16, cy+20], [cx-16, cy+20]], { stroke: '#4FC3F7', strokeWidth: 2, roughness: 1.8 }));
svg.appendChild(rc.rectangle(cx-10, cy+20, 20, 22, { stroke: '#4FC3F7', strokeWidth: 2, roughness: 1.8 }));
```

### Target / Bullseye (goal/objective)
```javascript
// cx, cy = center of target
svg.appendChild(rc.circle(cx, cy, 60, { stroke: '#FF4081', strokeWidth: 1.5, roughness: 1.5 }));
svg.appendChild(rc.circle(cx, cy, 38, { stroke: '#FF4081', strokeWidth: 1.5, roughness: 1.5 }));
svg.appendChild(rc.circle(cx, cy, 16, { stroke: '#FF4081', strokeWidth: 2.0, roughness: 1.5, fill: '#FF4081', fillStyle: 'solid' }));
```

---

## 9. Text Placement Reference

Note: Positions below are examples. Apply ±5-15px jitter for organic feel. Minimum 22px for all primary labels. 18px only for Tier 4 sub-labels directly below a Tier 3 element.

```html
<!-- Main Title — Tier 1 (Yellow, top-left area, stagger from exact corner) -->
<div class="wb-text" style="left: 65px; top: 45px; font-size: 52px; font-weight: 700; color: #FFD54F;">
  Topic Title Here
</div>

<!-- Problem Statement — Tier 2 (Pink, near top) -->
<div class="wb-text" style="left: 70px; top: 120px; font-size: 28px; font-weight: 500; color: #FF4081;">
  The Problem: vanishing gradients in deep networks
</div>

<!-- Solution Label — Tier 2 (Green) -->
<div class="wb-text" style="left: 1200px; top: 305px; font-size: 30px; font-weight: 600; color: #69F0AE;">
  Solution: Skip Connections
</div>

<!-- Annotation — Tier 3 (White) -->
<div class="wb-text" style="left: 805px; top: 525px; font-size: 24px; font-weight: 400; color: #E0E0E0;">
  each layer adds its input back
</div>

<!-- Entity Label — Tier 3 (Cyan) -->
<div class="wb-text" style="left: 405px; top: 755px; font-size: 24px; font-weight: 500; color: #4FC3F7;">
  Microsoft Research, 2015
</div>

<!-- Labeled Group: Step name (Tier 3) + Role attribution (Tier 4) — counts as 1 semantic group -->
<div class="wb-text" style="left: 120px; top: 287px; width: 130px; text-align: center; font-size: 22px; font-weight: 600; color: #E0E0E0;">SPECIFY</div>
<div class="wb-text" style="left: 120px; top: 313px; width: 130px; text-align: center; font-size: 18px; font-weight: 400; color: #AAAAAA;">(Human)</div>

<!-- Labeled Group: Artifact name (Tier 3) + Description (Tier 4) — counts as 1 semantic group -->
<div class="wb-text" style="left: 105px; top: 780px; font-size: 22px; font-weight: 500; color: #4FC3F7;">proposal.md</div>
<div class="wb-text" style="left: 105px; top: 806px; font-size: 18px; font-weight: 400; color: #AAAAAA;">The why &amp; what</div>

<!-- Text centered inside a Rough.js box: rc.rectangle(500, 268, 160, 55) with 22px text -->
<!-- Formula: left = boxX, width = boxW, text-align: center, top = boxY + (boxH - fontSize*1.2)/2 -->
<div class="wb-text" style="left: 500px; top: 285px; width: 160px; text-align: center; font-size: 22px; font-weight: 500; color: #E0E0E0;">
  Step Label
</div>
```

---

## 10. Weighted Scoring Rubric

Score every generated whiteboard against this rubric before accepting the output (see Step 10 in Section 7). Each dimension is scored 1-5, then multiplied by its weight. **Target: ≥76/95 (80%).**

### Scoring Scale

| Score | Meaning |
|-------|---------|
| 1 | Failing — rule is violated or element is missing entirely |
| 2 | Poor — partially present but major issues |
| 3 | Acceptable — meets minimum bar, noticeable room for improvement |
| 4 | Good — solid execution, minor imperfections |
| 5 | Excellent — matches reference image quality |

### Rubric Dimensions

#### 3x Weight (Critical) — These break the whiteboard if wrong

**R5: Alignment & Overflow (×3)**
No text overlaps other text. No text bleeds outside container boxes. No element clips at canvas edges (50px safe area). All text inside artifact boxes has ≥20px padding. All text elements have ≥40px clearance from each other. Text labels inside Rough.js boxes must be centered using the `left`/`width`/`text-align:center` technique — not manually estimated pixel offsets.
- 1 = Multiple overlaps or overflows visible
- 3 = One minor overlap or tight spacing issue
- 5 = Zero overlaps, all spacing clean

**R9: Readability at Distance (×3)**
Every text element is legible if projected on a screen viewed from 6 feet. Primary labels ≥22px. Key labels ≥28px. Title ≥48px. Tier 4 descriptors (18-20px) are permitted but must be immediately adjacent to a larger label and not used as standalone information. Sufficient contrast against black background.
- 1 = Multiple primary elements too small to read, or low contrast
- 3 = Most text readable, one or two primary elements borderline
- 5 = All text immediately legible, clear hierarchy, Tier 4 only used as descriptors

#### 2x Weight (High) — These define whiteboard quality

**R3: Visual Sketches (×2)**
At least one genuine Rough.js drawn illustration exists (not just text labels or boxes). The metaphor is visually recognizable without reading labels. Minimum 8 Rough.js drawing calls for the metaphor. Uses recipes from Section 5.E or equivalent original sketches.
- 1 = No drawn illustrations, metaphor is text-only
- 3 = Some drawn shapes but not recognizable as a coherent illustration
- 5 = Clear, recognizable sketched illustration that communicates the concept

**R6: Organic Feel (×2)**
Layout feels hand-placed, not grid-snapped. Positions have ±5-15px jitter. Connectors use `rc.curve()` not straight lines. Margins are asymmetric. Element sizes vary. No perfect vertical/horizontal alignment of unrelated elements.
- 1 = Rigid grid layout, all elements perfectly aligned, straight connectors
- 3 = Some organic variation but still feels mechanical
- 5 = Genuinely hand-drawn feel, natural clustering, varied spacing

**R10: Content Originality (×2)**
All structured content from source markdown (tables, lists, code blocks) is visually reinterpreted as schematic drawings rather than reproduced as HTML text. Only titles and short key quotes may remain verbatim.
- 1 = Multiple tables/lists/code blocks reproduced verbatim as HTML text
- 3 = Most structured content reinterpreted visually, one instance of verbatim reproduction
- 5 = All structured content synthesized into visual schematics, only titles/quotes used verbatim

#### 1x Weight (Standard) — Important but not make-or-break

**R1: Negative Space (×1)**
Negative space target is mode-dependent. Conceptual mode: 45-55% black. Structured mode: 30-40% black. Large breathing gaps between clusters (≥80px). The black space creates visual rhythm.
- 1 = Far below mode target (e.g., <25% for conceptual, <20% for structured), canvas feels packed
- 3 = Slightly below mode target but readable
- 5 = Within mode target range, strong visual impact from emptiness

**R2: Content Density (×1)**
Maximum 10 semantic groups per panel. Each group (primary label + optional descriptor + optional sub-note) earns its place. No redundant groups. If stripped to group names only, it would read like concise outline notes.
- 1 = >15 semantic groups, information overload
- 3 = 11-12 groups, slightly crowded
- 5 = ≤10 groups, every one essential

**R4: Typography Hierarchy (×1)**
Clear 4-tier hierarchy visible: title (Tier 1: 48-56px), section headers/labels (Tier 2: 28-40px), labels/annotations (Tier 3: 22-26px), sub-labels only (Tier 4: 18-20px, used sparingly). Font weights vary to reinforce hierarchy (700 → 600 → 500 → 400). Colors reinforce hierarchy per semantic palette. Tier 4 only appears below a Tier 3 element.
- 1 = All text same size, no visual hierarchy
- 3 = Some size variation but hierarchy unclear or Tier 4 used as primary
- 5 = Immediately obvious what to read first, second, third; Tier 4 descriptors correctly subordinate

**R7: Focal Clarity (×1)**
One dominant visual element draws the eye first. Supporting elements radiate outward. A viewer's eye path is: focal point → annotations → secondary elements. No two elements compete for dominance.
- 1 = Multiple elements compete equally, no clear entry point
- 3 = Focal point exists but other elements distract
- 5 = Unmistakable focal point, clear visual hierarchy of attention

**R8: Color Semantics (×1)**
Colors follow the semantic mapping in Section 4. Yellow = headers/labels only. Pink = problems only. Green = solutions only. Red used ≤3 times. White/gray is the dominant text color. No decorative color use.
- 1 = Colors used randomly, no semantic meaning
- 3 = Mostly correct but one or two violations
- 5 = Perfect semantic color usage throughout

**R11: Structural Clarity (×2)**
Content is organized into visually distinct zones or clusters. Related text elements are grouped (labeled group pattern). A viewer can identify 3-5 discrete information clusters without reading the text. Applies to all whiteboards; most impactful for structured-mode content.
- 1 = Content scattered randomly, no visual grouping, viewer has no clear scan path
- 3 = Some clustering but zone/group boundaries unclear; viewer must read to navigate
- 5 = Clear zones or clusters with consistent internal structure; viewer identifies 3-5 information areas at a glance

### Score Calculation

```
Weighted Total = (R1×1) + (R2×1) + (R3×2) + (R4×1) + (R5×3) + (R6×2) + (R7×1) + (R8×1) + (R9×3) + (R10×2) + (R11×2)
Maximum = 5×(1+1+2+1+3+2+1+1+3+2+2) = 5×19 = 95
Target  = 76/95 (80%)
```

### Quick Score Card Template

Use this format when reporting scores in Step 12:

```
R1 Negative Space       (×1): _/5 = __
R2 Content Density      (×1): _/5 = __
R3 Visual Sketches      (×2): _/5 = __
R4 Typography           (×1): _/5 = __
R5 Alignment            (×3): _/5 = __
R6 Organic Feel         (×2): _/5 = __
R7 Focal Clarity        (×1): _/5 = __
R8 Color Semantics      (×1): _/5 = __
R9 Readability          (×3): _/5 = __
R10 Content Originality (×2): _/5 = __
R11 Structural Clarity  (×2): _/5 = __
─────────────────────────────
TOTAL:                  __/95
TARGET:                 76/95 (80%)
```

### Pre-Generation Sanity Checks

Before writing the HTML (Step 7), verify these hard constraints. These are pass/fail — any failure must be fixed before proceeding:

- [ ] Background is pure black (`#000`), no gridlines.
- [ ] **ZERO white or near-white backgrounds anywhere.** Scan every CSS `background`, `background-color`, and `fill` property in the generated HTML. No value may have all three RGB channels above `#C0`. `.artifact-box` must use `background: #000`. If any light background is found, replace it with `#000` before saving.
- [ ] **All text inside artifact boxes uses light colors.** `.artifact-text` must default to `color: #E0E0E0`. No `color: #222`, `#333`, or other dark text colors inside artifacts.
- [ ] Caveat font loaded via Google Fonts CDN.
- [ ] Rough.js loaded via CDN, all drawn elements use it (no perfect SVG shapes).
- [ ] Export PNG button included with html2canvas script.
- [ ] All Rough.js roughness values are between 1.0 and 2.5.
- [ ] File will be saved as `whiteboard-[topic-slug].html`.
